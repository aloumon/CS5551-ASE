export const environment = {
  googleCloudVisionAPIKey: "AIzaSyBM-8OAGOsrPY5mSPqQGdkJEW5AF2Ts5KY"
  // Using the browser key
};
