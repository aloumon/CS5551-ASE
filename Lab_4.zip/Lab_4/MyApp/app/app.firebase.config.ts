export const FIREBASE_CONFIG =  {
  apiKey: "AIzaSyCLSmTEPyPd8lKsjGC2xtVOPgUq5fHDpPs",
  authDomain: "asemax226.firebaseapp.com",
  databaseURL: "https://asemax226.firebaseio.com",
  projectId: "asemax226",
  storageBucket: "asemax226.appspot.com",
  messagingSenderId: "489123086268"
};
